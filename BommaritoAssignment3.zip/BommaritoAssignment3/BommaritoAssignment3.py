import csv
import json

#Creates an empty list called "sales_data"
sales_data = []

#Opens up this file (SalesJan2009.csv - you need to download it to your hard drive) and converts the data within it to JSON format.  The fields in the file are listed in order as follows:
with open('/Users/marissabommarito/Downloads/SalesJan2009.csv', 'r') as csv_file:
    csvappendreader = csv.reader(csv_file)
    
    # Skip the header row
    next(csvappendreader, None)
    
    # Processing each line individually in the CSV file and create an appended dictionary
    for row in csvappendreader:
        # Clean up extra quote characters
        row = [item.strip('"') for item in row]
        
        # Extract data fields
        transaction_date, product, price, payment_type, name, city, state, country = row
        
        # Create a dictionary for each line
        transaction_dict = {
            "Transaction_date": transaction_date,
            "Product": product,
            "Price": float(price),  # Convert price to a float
            "Payment_Type": payment_type,
            "Name": name,
            "City": city,
            "State": state,
            "Country": country
        }
        
        # Append the dictionary to the sales_data list
        sales_data.append(transaction_dict)

#At the end of your processing, you will save your sales_data list to a file called "transaction_data.json"
with open('transaction_data.json', 'w') as json_file:
    json.dump(sales_data, json_file, indent=4)

#Affordance for visual confirmation fo user to show script was executed successfully 
print("Data successfully appended and converted to JSON")